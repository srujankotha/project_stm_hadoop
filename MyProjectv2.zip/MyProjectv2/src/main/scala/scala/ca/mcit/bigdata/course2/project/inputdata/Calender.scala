package ca.mcit.bigdata.course2.project.inputdata

case class Calender(service_id:String,
                    monday:String,
                    tuesday:String,
                    wednesday:String,
                    thursday:String,
                    friday:String,
                    saturday:String,
                    sunday:String,
                    start_date:String,
                    end_date:String)
