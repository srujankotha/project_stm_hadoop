package ca.mcit.bigdata.course2.project.proccesed

import ca.mcit.bigdata.course2.project.inputdata.Calender

case class EnrichTrip(tripRoute: TripRoute, calender: Calender)
