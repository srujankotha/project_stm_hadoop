package ca.mcit.bigdata.course2.project.proccesed

import ca.mcit.bigdata.course2.project.inputdata._

case class TripRoute(trips: Trip, routes: Route)
