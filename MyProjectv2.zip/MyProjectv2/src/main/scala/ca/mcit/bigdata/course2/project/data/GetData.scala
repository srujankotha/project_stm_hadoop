package ca.mcit.bigdata.course2.project.data

import ca.mcit.bigdata.course2.project.inputdata.{Calender, Route, Trip}

import scala.io.Source

class GetData {

  val filePathRoutes = "/home/bd-user/Downloads/routes.txt"


  //noinspection SourceNotClosed
  def gRouteList = Source.fromFile(filePathRoutes).getLines().drop(1)
    .map(line => line.split(","))
    .map(a => Route(a(0).toInt, a(1), a(2), a(3), a(4).toInt, a(5), a(6))).toList

  val filePathCalender = "/home/bd-user/Downloads/calendar.txt"
  //noinspection SourceNotClosed
  def getCalenderList: List[Calender] = {
    Source.fromFile(filePathCalender)
      .getLines()
      .drop(1)
      .map(line => line.split(","))
      .map(a => Calender(a(0), a(1), a(2), a(3), a(4), a(5), a(6), a(7), a(8), a(9))).toList
  }
  val filePathTrips = "/home/bd-user/Downloads/trips.txt"
  //noinspection SourceNotClosed
  def getTripList: List[Trip] = Source.fromFile(name = filePathTrips)
    .getLines()
    .drop(1)
    .map(line => line.split(","))
    .map(a => Trip(a(0).toInt, a(1), a(2), a(3), a(4), a(5), a(6))).toList


}
